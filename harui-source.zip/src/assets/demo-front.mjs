import {BASE,KEY,defaults,read} from './demo-store.mjs';
import {renderSite} from './render.mjs';
try {
 const saved=read(await defaults());
 if(saved.revision) {
  const route=location.pathname.slice(BASE.length).replace(/index\.html$/, '')||'/';
  const html=renderSite(saved.data,{base:BASE})[route];
  if(html) {
   const page=new DOMParser().parseFromString(html,'text/html');
   document.body.replaceChildren(...page.body.children);
   document.title=page.title;document.body.className=page.body.className;
  }
 }
} catch(error) {
 const note=document.createElement('aside');note.className='notice';
 note.textContent='本機示範內容暫時無法載入，現在顯示原始版本。可到後台檢查備份。';
 document.querySelector('main')?.prepend(note);
}
// Demo forms never transmit customer data.
window.HARUI={base:BASE,endpoint:'',ga:false};
await import('./main.js');
window.addEventListener('storage',event=>{
 if(event.key===KEY) {
  if(document.querySelector('#inquiry')) {
   const note=document.createElement('p');note.className='notice';note.textContent='內容已在後台更新，完成填寫後可重新整理查看。';
   document.querySelector('main').prepend(note);
  } else location.reload();
 }
});
