// Device-local demonstration storage. This module is not an authentication service.
export const BASE = new URL('../', import.meta.url).pathname.replace(/\/$/, '');
export const KEY = `harui-editor-v1:${BASE}`;
export const AUTH_KEY = `${KEY}:session`;
export const clone = value => structuredClone(value);
export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export async function defaults() {
 const response=await fetch(new URL('defaults.json',import.meta.url));
 if(!response.ok) throw new Error('無法讀取網站內容，請重新整理。');
 return response.json();
}
export function validate(data,original) {
 const templates={faq:{q:'',a:''},news:{title:'',date:'',body:''},links:{title:'',url:''}};
 function walk(value,sample,path) {
  const key=path.split('.').at(-1);
  if(Array.isArray(sample)) {
   if(!Array.isArray(value)||value.length>100) throw new Error('清單內容格式不正確。');
   const item=sample[0]??templates[key];
   if(item) value.forEach((v,i)=>walk(v,item,`${path}.${i}`));
   if(['kits','variants'].includes(key)&&!value.length) throw new Error('請至少保留一個材料包和版本。');
  } else if(sample&&typeof sample==='object') {
   if(!value||typeof value!=='object'||Array.isArray(value)) throw new Error('內容結構不完整。');
   for(const [k,expected] of Object.entries(sample)) walk(value[k],expected,`${path}.${k}`);
   for(const k of Object.keys(value)) if(!(k in sample)||['__proto__','constructor','prototype'].includes(k)) throw new Error('備份含有無法辨識的欄位。');
  } else {
   if(typeof value!==typeof sample) throw new Error('欄位資料格式不正確。');
   if(typeof value==='number'&&(!Number.isFinite(value)||value<0||!Number.isInteger(value))) throw new Error('價格與難度請填有效的非負整數。');
   if(key==='difficulty'&&(value<1||value>5)) throw new Error('難度請填 1 到 5。');
   if(typeof value==='string') {
    if(value.length>1800000) throw new Error('圖片或文字太大，請縮小後再試。');
    if(['image','heroImage'].includes(key)&&value&&!/^(https:\/\/|\/(?!\/)|data:image\/(jpeg|png|webp);base64,)/i.test(value)) throw new Error('圖片請用 HTTPS 網址或上傳 JPG、PNG、WebP。');
    if(['buyUrl','url','link','facebook','instagram','siteUrl','inquiryEndpoint'].includes(key)&&value&&!/^https:\/\/[^\s]+$/i.test(value)) throw new Error('連結請填完整的 HTTPS 網址。');
    if(['name','heroTitle','siteName','shortName','q','a','title','body'].includes(key)&&!value.trim()) throw new Error('名稱、標題或內容不能留白。');
    if(key==='slug'&&!/^[a-z0-9-]+$/.test(value)) throw new Error('材料包代稱格式不正確。');
    if(key==='date'&&!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('請選擇公告日期。');
   }
  }
 }
 walk(data,original,'');
 if(data.catalog.kits.map(k=>k.slug).join('|')!==original.catalog.kits.map(k=>k.slug).join('|')) throw new Error('此示範後台不能更改材料包網址。');
 return data;
}
export function read(original,storage=localStorage) {
 const raw=storage.getItem(KEY);
 if(!raw) return {data:clone(original),revision:null};
 const record=JSON.parse(raw);
 if(record.version!==1) throw new Error('儲存資料版本不同，請匯入正確備份。');
 validate(record.data,original);
 return {data:record.data,revision:record.revision};
}
export function save(data,original,revision,storage=localStorage) {
 validate(data,original);
 if(read(original,storage).revision!==revision) throw new Error('另一個分頁已修改內容。請先匯出草稿，再重新整理以取得最新版本。');
 const next={version:1,revision:crypto.randomUUID(),updatedAt:new Date().toISOString(),data};
 if(JSON.stringify(next).length>3500000) throw new Error('儲存空間接近上限，請縮小照片或改用圖片網址。');
 storage.setItem(`${KEY}:previous`,storage.getItem(KEY)||JSON.stringify({version:1,revision:null,data:original}));
 storage.setItem(KEY,JSON.stringify(next));
 return next.revision;
}
