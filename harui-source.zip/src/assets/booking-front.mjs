import {loadContent,BASE} from './booking-cloud.mjs';
import {renderSite} from './render.mjs';
import {esc,money,upcoming,rocDate,bookingMessage,lineLinks} from './booking-model.mjs';
let data,revision,dirty=false,message='';
const route=location.pathname.slice(BASE.length).replace(/index\.html$/,'')||'/';
function render(record){data=record.content;revision=record.revision;const html=renderSite(data,{base:BASE})[route];if(html){const doc=new DOMParser().parseFromString(html,'text/html');document.body.replaceChildren(...doc.body.children);document.title=doc.title;}bind();}
function bind(){
 const form=document.querySelector('#booking-form');if(!form)return;
 const cs=form.elements.courseId,ss=form.elements.slot,ps=form.elements.people;
 const update=()=>{const c=data.courses.find(c=>c.id===cs.value);const slots=c?upcoming(c):[];ss.innerHTML='<option value="">'+(slots.length?'請選擇上課時間':'目前沒有可預約時段')+'</option>'+slots.map(s=>`<option value="${esc(s.date+' '+s.time)}">${rocDate(s.date)} ${s.time}</option>`).join('');ss.disabled=!slots.length;ps.innerHTML='<option value="">請先選擇時段</option>';ps.disabled=true;if(c)document.querySelector('#selected-course').innerHTML=`${c.image?`<img src="${esc(c.image)}" alt="${esc(c.title)}">`:''}<h2>${esc(c.title)}</h2><p>${esc(c.duration)} · ${esc(c.level)}</p><p>${money(c.price)}／人</p>`;};
 cs.addEventListener('change',()=>{dirty=true;update();});ss.addEventListener('change',()=>{const c=data.courses.find(c=>c.id===cs.value),s=c&&upcoming(c).find(s=>s.date+' '+s.time===ss.value);ps.disabled=!s;ps.innerHTML=s?Array.from({length:s.capacity},(_,i)=>`<option value="${i+1}">${i+1} 位</option>`).join(''):'<option value="">請先選擇時段</option>';});
 const chosen=new URLSearchParams(location.search).get('course');if(chosen&&[...cs.options].some(o=>o.value===chosen)){cs.value=chosen;update();}
 form.addEventListener('input',()=>{dirty=true;});
 form.addEventListener('submit',async e=>{e.preventDefault();const status=document.querySelector('#booking-status'),button=form.querySelector('button[type=submit]');button.disabled=true;status.textContent='正在確認最新課程資訊…';try{const latest=await loadContent();if(latest.revision!==revision){data=latest.content;revision=latest.revision;update();throw Error('店家剛更新課程資訊，請重新選擇時段後確認。');}message=bookingMessage(data,Object.fromEntries(new FormData(form)));const links=lineLinks(data.site.lineId,message);document.querySelector('#message-preview').textContent=message;document.querySelector('#line-message').href=links.message;document.querySelector('#line-friend').href=links.friend;form.hidden=true;const result=document.querySelector('#booking-result');result.hidden=false;result.focus();status.textContent='';}catch(err){status.textContent=err.message;}finally{button.disabled=false;}});
 document.querySelector('#copy-message').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(message);document.querySelector('#result-status').textContent='已複製，可貼到官方 LINE 對話。';}catch{document.querySelector('#result-status').textContent='請長按上方預約內容，手動複製。';}});
 document.querySelector('#edit-booking').addEventListener('click',()=>{document.querySelector('#booking-result').hidden=true;form.hidden=false;cs.focus();});
}
try{render(await loadContent());}catch{const notice=document.querySelector('#sync-notice');notice.textContent='目前無法取得最新課程，請稍後重新整理或電話洽詢。';const submit=document.querySelector('#booking-form button[type=submit]');if(submit)submit.disabled=true;}
async function refresh(){if(document.hidden)return;try{const next=await loadContent();if(next.revision!==revision){if(dirty){document.querySelector('#sync-notice').textContent='店家已更新課程，送出前會再確認最新資訊。';}else render(next);}}catch{/* Keep the last readable content; submission always rechecks. */}}
setInterval(refresh,30000);window.addEventListener('focus',refresh);
