// A local, non-publishing preview gate; never used for a configured cloud project.
export function localPreviewAllowed(hostname, config) {
  return ['localhost', '127.0.0.1', '[::1]'].includes(hostname)
    && !config.url && !config.publishableKey && !config.adminEmail;
}

export function previewPasswordMatches(password) {
  return password === '123456';
}
