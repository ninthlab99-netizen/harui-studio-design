export const esc=(s='')=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const money=n=>`NT$ ${Number(n).toLocaleString('en-US')}`;
export const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export function rocDate(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value)||new Date(value+'T12:00:00Z').toISOString().slice(0,10)!==value)throw Error('日期格式不正確');const [y,m,d]=value.split('-');return `${Number(y)-1911}/${m}/${d}`;}
export const upcoming=(course,now=Date.now())=>course.slots.filter(s=>s.open&&Date.parse(`${s.date}T${s.time}:00+08:00`)>now&&s.capacity>0);
export function imageURL(s){return s===''||/^https:\/\/[^\s]+$/.test(s)||/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(s);}
export function validate(data){
 if(!data||!data.site||!Array.isArray(data.courses)||data.courses.length>60)throw Error('課程資料格式不正確');
 for(const k of ['name','englishName','logo','heroTitle','heroText','heroImage','story','address','phone','email','lineId','announcement','bookingNote'])if(typeof data.site[k]!=='string'||data.site[k].length>(['logo','heroImage'].includes(k)?2000000:3000))throw Error('網站欄位不正確：'+k);
 if(!imageURL(data.site.logo)||!imageURL(data.site.heroImage))throw Error('圖片需使用 HTTPS 網址或上傳圖片');
 if(data.site.lineId&&!/^@[a-zA-Z0-9._-]{2,50}$/.test(data.site.lineId))throw Error('LINE 帳號請使用 @ 開頭的官方 ID');
 const ids=new Set();for(const c of data.courses){
 if(!/^[a-zA-Z0-9-]{1,80}$/.test(c.id)||ids.has(c.id))throw Error('課程編號不可重複');ids.add(c.id);
 for(const k of ['title','subtitle','description','image','duration','level'])if(typeof c[k]!=='string'||c[k].length>(k==='image'?2000000:3000))throw Error('課程欄位不正確');
 if(!c.title.trim()||!imageURL(c.image)||!Number.isInteger(c.price)||c.price<0||c.price>1000000||!['open','coming','hidden'].includes(c.status)||!Array.isArray(c.slots)||c.slots.length>200)throw Error('請檢查課程名稱、價格與狀態');
 const slots=new Set();for(const s of c.slots){rocDate(s.date);if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(s.time)||!Number.isInteger(s.capacity)||s.capacity<1||s.capacity>100||typeof s.open!=='boolean'||slots.has(s.date+s.time))throw Error('時段格式錯誤、重複或人數不正確');slots.add(s.date+s.time);}
 }return data;
}
export function bookingMessage(data,form,now=Date.now()){
 const c=data.courses.find(c=>c.id===form.courseId&&c.status==='open');if(!c)throw Error('此課程尚未開放，請重新選擇');
 const s=upcoming(c,now).find(s=>`${s.date} ${s.time}`===form.slot);if(!s)throw Error('此時段已更新或截止，請重新選擇');
 const count=Number(form.people);if(!Number.isInteger(count)||count<1||count>s.capacity)throw Error('請選擇可預約的人數');
 const name=String(form.name||'').trim(),note=String(form.note||'').trim();if(!name||name.length>40||note.length>300)throw Error('請填寫稱呼（40 字內）與備註（300 字內）');
 return `您好，我想預約${rocDate(s.date)} ${c.title}課程。\n時間：${s.time}（台北時間）\n人數：${count} 位\n稱呼：${name}\n課程費用：${money(c.price)}／人，合計 ${money(c.price*count)}\n${note?'備註：'+note+'\n':''}請協助確認名額，並提供付款資訊與訂金金額，謝謝！\n（以店家回覆確認為準，尚未完成訂位或付款。）`;
}
export function lineLinks(id,message){if(!/^@[a-zA-Z0-9._-]{2,50}$/.test(id))throw Error('官方 LINE 尚未設定，請先電話洽詢');return {friend:`https://line.me/R/ti/p/${encodeURIComponent(id)}`,message:`https://line.me/R/oaMessage/${encodeURIComponent(id)}/?${encodeURIComponent(message)}`};}
