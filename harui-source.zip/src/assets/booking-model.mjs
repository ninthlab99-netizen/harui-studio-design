export const esc=(s='')=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const money=n=>`NT$ ${Number(n).toLocaleString('en-US')}`;
export const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export function rocDate(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value)||new Date(value+'T12:00:00Z').toISOString().slice(0,10)!==value)throw Error('日期格式不正確');const [y,m,d]=value.split('-');return `${Number(y)-1911}/${m}/${d}`;}
export const upcoming=(course,now=Date.now())=>course.slots.filter(s=>s.open&&Date.parse(`${s.date}T${s.time}:00+08:00`)>now&&s.capacity>0);
export function imageURL(s){return s===''||/^https:\/\/[^\s]+$/.test(s)||/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(s);}
export function validate(data){
 if(!data||!data.site||!Array.isArray(data.courses)||data.courses.length>600)throw Error('課程資料格式不正確');
 for(const k of ['name','englishName','logo','heroTitle','heroText','heroImage','story','address','phone','email','lineId','announcement','bookingNote'])if(typeof data.site[k]!=='string'||data.site[k].length>(['logo','heroImage'].includes(k)?2000000:3000))throw Error('網站欄位不正確：'+k);
 if(!imageURL(data.site.logo)||!imageURL(data.site.heroImage))throw Error('圖片需使用 HTTPS 網址或上傳圖片');
 if(data.site.lineId&&!/^@[a-zA-Z0-9._-]{2,50}$/.test(data.site.lineId))throw Error('LINE 帳號請使用 @ 開頭的官方 ID');
 const b=data.booking;if(!b||!Number.isInteger(b.minDays)||b.minDays<1||b.minDays>365||!Array.isArray(b.weekdays)||!b.weekdays.length||b.weekdays.some(n=>!Number.isInteger(n)||n<0||n>6)||!Array.isArray(b.times)||!b.times.length||b.times.some(t=>!/^([01]\d|2[0-3]):[0-5]\d$/.test(t))||!Array.isArray(b.closedDates))throw Error('預約日期設定不正確');b.closedDates.forEach(rocDate);
 if(data.leather){if(typeof data.leather.note!=='string'||data.leather.note.length>3000||!['sourceImage','photo'].every(k=>/^\/assets\/leather\/[a-z0-9-]+\.(png|jpg|webp)$/.test(data.leather[k])))throw Error('皮革參考圖片或說明不正確');if(!Array.isArray(data.leather.colors)||data.leather.colors.length>50||!data.leather.colors.every(c=>/^[a-z0-9-]+$/.test(c.id)&&typeof c.name==='string'&&/^#[A-Fa-f0-9]{6}$/.test(c.hex))||new Set(data.leather.colors.map(c=>c.id)).size!==data.leather.colors.length)throw Error('皮革色卡資料不正確');}
 if(data.notices&&(!Array.isArray(data.notices)||data.notices.length>20||data.notices.some(n=>typeof n.title!=='string'||typeof n.text!=='string'||n.text.length>3000)))throw Error('預約須知格式不正確');
 const ids=new Set();for(const c of data.courses){
 if(!/^[a-zA-Z0-9-]{1,80}$/.test(c.id)||ids.has(c.id))throw Error('課程編號不可重複');ids.add(c.id);
 if(!Array.isArray(c.categories)||!c.categories.length||c.categories.some(x=>typeof x!=='string'||!x.trim()||x.length>80))throw Error('請填寫作品分類');
 for(const k of ['title','subtitle','description','image','duration','level'])if(typeof c[k]!=='string'||c[k].length>(k==='image'?2000000:3000))throw Error('課程欄位不正確');
 if(!c.title.trim()||!imageURL(c.image)||!Number.isInteger(c.price)||c.price<0||c.price>1000000||!['open','coming','hidden'].includes(c.status)||!Array.isArray(c.slots)||c.slots.length>200)throw Error('請檢查課程名稱、價格與狀態');
 const slots=new Set();for(const s of c.slots){rocDate(s.date);if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(s.time)||!Number.isInteger(s.capacity)||s.capacity<1||s.capacity>100||typeof s.open!=='boolean'||slots.has(s.date+s.time))throw Error('時段格式錯誤、重複或人數不正確');slots.add(s.date+s.time);}
 }return data;
}
export function minimumDate(data,now=Date.now()) {const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(now));return new Date(Date.parse(day+'T00:00:00Z')+data.booking.minDays*86400000).toISOString().slice(0,10);}
export function bookingMessage(data,form,now=Date.now()){
 rocDate(form.date);
 if(form.date<minimumDate(data,now)||!data.booking.weekdays.includes(new Date(form.date+'T12:00:00Z').getUTCDay())||data.booking.closedDates.includes(form.date))throw Error('請選擇符合提前預約天數、開放星期且未休息的日期');
 if(!data.booking.times.includes(form.time))throw Error('請選擇希望上課時間');
 if(!Array.isArray(form.items)||!form.items.length||form.items.length>10)throw Error('請選擇 1 至 10 種作品；更多作品請直接洽詢');
 const seen=new Set();let total=0;
 const lines=form.items.map(item=>{const c=data.courses.find(c=>c.id===item.id&&c.status==='open');if(!c||seen.has(item.id))throw Error('作品已更新或暫停預約，請重新選擇');seen.add(item.id);if(!Number.isInteger(item.quantity)||item.quantity<1||item.quantity>10)throw Error('每種作品請選擇 1 至 10 件');const color=item.colorId?data.leather?.colors.find(x=>x.id===item.colorId):null;if(item.colorId&&!color)throw Error('皮色色卡已更新，請重新選色');total+=c.price*item.quantity;return `${c.title} × ${item.quantity} 件｜${money(c.price)}／件｜${c.duration}｜希望皮色：${color?.name||'與店家討論'}`;});
 for(const k of ['name','age','country','phone','email','color'])if(!String(form[k]||'').trim()||String(form[k]).length>300)throw Error('請完整填寫聯絡資料、年齡、國家與希望皮色（各 300 字內）');
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))throw Error('請填寫有效的 email');
 if(String(form.note||'').length>500||String(form.offer||'').length>300)throw Error('備註內容過長');
 return `您好，我想預約${rocDate(form.date)}皮革手作課程。\n希望時間：${form.time}（台北時間，待店家確認）\n${lines.join('\n')}\n原價參考合計：${money(total)}\n稱呼：${form.name}\n年齡：${form.age}｜國家：${form.country}\n手機：${form.phone}\nEmail：${form.email}\n希望皮色／製作安排：${form.color}\n會員／優惠詢問：${form.offer||'無'}\n其他備註：${form.note||'無'}\n每件作品限一人製作；多日作品請協助安排後續日期。\n請確認作品、日期與適用優惠，提供付款資訊及訂金金額，謝謝！\n（尚未完成訂位或付款，以店家回覆為準。）`;
}
export function lineLinks(id,message){if(!/^@[a-zA-Z0-9._-]{2,50}$/.test(id))throw Error('官方 LINE 尚未設定，請先電話洽詢');return {friend:`https://line.me/R/ti/p/${encodeURIComponent(id)}`,message:`https://line.me/R/oaMessage/${encodeURIComponent(id)}/?${encodeURIComponent(message)}`};}
