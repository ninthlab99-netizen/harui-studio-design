# 春豬工作室前台與後台設計示範

這是獨立專案，與原網站分開維護。

- 前台：https://ninthlab99-netizen.github.io/harui-studio-design/
- 後台：https://ninthlab99-netizen.github.io/harui-studio-design/admin/
- 示範密碼：123456

後台可修改首頁、照片、材料包價格、消息、教學與聯絡資訊。儲存只影響操作的瀏覽器，不會同步所有訪客或寫回 GitHub。這是內容管理示範，請勿存放私密資料。可匯出內容備份。

## 建置與發布

Node 20 以上，無額外套件依賴。

```sh
BASE_PATH=/harui-studio-design SITE_URL=https://ninthlab99-netizen.github.io OUTPUT_DIR=docs node build.mjs
```

GitHub Pages 使用 main 分支的 /docs 目錄。更新來源後請重新建置並將 docs 一起提交。本機預覽可用 node build.mjs 產生 dist，再啟動靜態伺服器。測試：node build.mjs 後執行 node --test tests/content.test.mjs。

content 為預設資料，src/assets 為前台，admin 為編輯器。DESIGN.md 保存品牌設計原則。正式共用後台仍需伺服器驗證與雲端儲存。

來源設計延續 harui-studio/harui-studio；這份專案不會修改原網站。
