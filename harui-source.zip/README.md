# Harui Studio — 手作課程與 LINE 預約

獨立專案：ninthlab99-netizen/harui-studio-design。保留原有 Node 靜態建置，公開站由 GitHub Pages 提供；課程內容改讀取獨立 Supabase 專案。

## 本機

`OUTPUT_DIR=preview-courses node build.mjs`

`python3 -m http.server 8790 --bind 127.0.0.1 --directory preview-courses`

`node --test tests/content.test.mjs`

首頁 `/`、預約 `/booking/`、管理 `/admin/`。舊材料包路徑顯示課程引導頁。建置使用資源白名單，不再包含材料包資料與舊本機密碼編輯器。部署請使用全新輸出目錄，勿沿用舊版 dist/docs。

## 功能

- 課程名稱、介紹、圖片、費用、狀態、日期、時間及單次詢問人數上限。
- 後台品牌 Logo、首頁文字、圖片、聯絡資訊、官方 LINE ID 與訂金說明。
- 圖片上傳縮圖存入內容；密碼由 Supabase Auth 驗證，前端沒有硬編碼密碼。
- 一份雲端內容，前台每 30 秒或返回分頁時更新。輸入中的表單保留，生成預約內容前重查最新版本。
- 樂觀鎖定防止兩位管理者互相覆寫；可下载草稿備份。
- 預約為 LINE 詢問流程，不是自動保留名額。網站不保存客人資料，也不收款；沒有訂單管理或名額自動扣除。
- 訊息包含民國日期、課程、時段、人數、稱呼、費用與備註；LINE 自動填入後由客人按傳送。首次加好友後可回本站再開訊息，並提供複製備援。

## 尚待啟用

`content/cloud.json` 目前為空，故後台只提供明確標示的管理畫面預覽，不能儲存。此狀態不得稱為已完成雲端串接。

1. 使用者選擇 Supabase 組織並確認費用後建立獨立專案，不沿用 ELVO 或其他網站。
2. 在該專案驗證並執行 `supabase/migrations/202610130001_course_content.sql`，以 content/booking.json 初始化 id=1。
3. 建立單一管理員 Supabase Auth 帳戶，將 UUID 加到 studio_admins。停用公開註冊；管理密碼由 Auth 設定（使用者先前要求初始 123456），不可寫入程式碼。前端只顯示密碼輸入，固定管理員 email 放設定檔。
4. content/cloud.json 填入 project URL、publishableKey、adminEmail。禁止填入 service_role key。
5. 官方 LINE 已由使用者確認為 @nkf1685l；確認開課日期後由後台輸入並開放。
6. 實際驗證匿名寫入失敗、非管理員寫入失敗、管理員登入儲存、另一裝置讀取更新、衝突保護；跑資料庫 security/performance advisors。
7. 使用者核准後再更新來源壓縮檔並部署。

目前驗證包括模型與雲端請求的模擬測試、瀏覽器表單與 LINE URL 編碼檢查。尚未進行正式 Supabase 或真實 LINE 帳號的端到端驗證。
