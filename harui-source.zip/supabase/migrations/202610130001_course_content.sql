-- Isolated Harui project only. No customer data is stored by this LINE enquiry flow.
create table public.studio_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.studio_admins enable row level security;
revoke all on public.studio_admins from anon, authenticated;
grant select on public.studio_admins to authenticated;
create policy "admin may read own membership" on public.studio_admins
for select to authenticated using (user_id = (select auth.uid()));

create table public.studio_content (
  id integer primary key default 1 check (id = 1),
  content jsonb not null check (
    jsonb_typeof(content) = 'object'
    and content ? 'site' and content ? 'courses'
    and jsonb_typeof(content->'site') = 'object'
    and jsonb_typeof(content->'courses') = 'array'
    and octet_length(content::text) < 8000000
  ),
  revision integer not null default 0 check (revision >= 0),
  updated_at timestamptz not null default now()
);
alter table public.studio_content enable row level security;
revoke all on public.studio_content from anon, authenticated;
grant select on public.studio_content to anon, authenticated;
grant update (content, revision) on public.studio_content to authenticated;
create policy "visitors read published content" on public.studio_content
for select to anon, authenticated using (id = 1);
create policy "only studio admins update content" on public.studio_content
for update to authenticated
using (exists(select 1 from public.studio_admins where user_id = (select auth.uid())))
with check (exists(select 1 from public.studio_admins where user_id = (select auth.uid())));

create function public.studio_content_revision_guard() returns trigger
language plpgsql security invoker set search_path = '' as $$
begin
  if new.revision <> old.revision + 1 then
    raise exception 'Content revision must increment by one';
  end if;
  new.updated_at = now();
  return new;
end;
$$;
revoke all on function public.studio_content_revision_guard() from public, anon, authenticated;
create trigger studio_content_revision_guard before update on public.studio_content
for each row execute function public.studio_content_revision_guard();
