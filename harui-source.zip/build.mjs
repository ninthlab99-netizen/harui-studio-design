// Pure static build; source content stays separate from the demo browser editor.
import {readFileSync,writeFileSync,mkdirSync,cpSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {renderSite} from './src/assets/render.mjs';
const root=dirname(fileURLToPath(import.meta.url));
const read=f=>JSON.parse(readFileSync(join(root,'content',f),'utf8'));
const data={site:read('site.json'),catalog:read('kits.json'),tutorials:read('tutorials.json')};
const base=(process.env.BASE_PATH||'').replace(/\/$/,'');
const out=join(root,process.env.OUTPUT_DIR||'dist');
const pages=renderSite(data,{base,siteUrl:process.env.SITE_URL||data.site.siteUrl});
for(const [path,html] of Object.entries(pages)){
 const file=join(out,path.endsWith('.html')?path:path+'index.html');
 mkdirSync(dirname(file),{recursive:true});writeFileSync(file,html);
}
for(const [from,to] of [['src/assets','assets'],['admin','admin'],['content','content']]) cpSync(join(root,from),join(out,to),{recursive:true});
writeFileSync(join(out,'assets/defaults.json'),JSON.stringify(data));
writeFileSync(join(out,'.nojekyll'),'');
writeFileSync(join(out,'robots.txt'),'User-agent: *\nDisallow: /\n');
console.log(`Built ${Object.keys(pages).length} pages; base ${base||'/'}`);
