import {readFileSync,writeFileSync,mkdirSync,cpSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {renderSite} from './src/assets/render.mjs';
import {validate} from './src/assets/booking-model.mjs';
const root=dirname(fileURLToPath(import.meta.url));
const data=validate(JSON.parse(readFileSync(join(root,'content/booking.json'),'utf8')));
const base=(process.env.BASE_PATH||'').replace(/\/$/,'');
const out=join(root,process.env.OUTPUT_DIR||'dist');
for(const [path,html] of Object.entries(renderSite(data,{base}))){const file=join(out,path.endsWith('.html')?path:path+'index.html');mkdirSync(dirname(file),{recursive:true});writeFileSync(file,html);}
// Explicit allowlist excludes the retired kit storefront and demo-password scripts.
for(const folder of ['assets','admin','content'])mkdirSync(join(out,folder),{recursive:true});
for(const name of ['booking-model.mjs','booking-cloud.mjs','booking-front.mjs','booking.css','render.mjs','admin-access.mjs'])cpSync(join(root,'src/assets',name),join(out,'assets',name));
for(const name of ['index.html','admin.mjs'])cpSync(join(root,'admin',name),join(out,'admin',name));
for(const name of ['booking.json','cloud.json'])cpSync(join(root,'content',name),join(out,'content',name));
writeFileSync(join(out,'.nojekyll'),'');writeFileSync(join(out,'robots.txt'),'User-agent: *\nDisallow: /\n');console.log('Built course booking site: '+out);
