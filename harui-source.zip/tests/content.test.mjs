import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {renderSite} from '../src/assets/render.mjs';
import {KEY,validate,read,save} from '../src/assets/demo-store.mjs';
const readJSON=p=>JSON.parse(readFileSync(new URL('../content/'+p,import.meta.url)));
const original={site:readJSON('site.json'),catalog:readJSON('kits.json'),tutorials:readJSON('tutorials.json')};
const copy=()=>structuredClone(original);
const memory=()=>{const values=new Map();return {getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v)}};
test('stored price updates list, detail and version choices consistently',()=>{
 const data=copy();data.catalog.kits[0].variants[0].price=1680;
 const storage=memory(),revision=save(data,original,null,storage);
 assert.equal(read(original,storage).revision,revision);
 const pages=renderSite(read(original,storage).data,{base:'/harui-studio'});
 assert.match(pages['/kits/pen-case/'],/NT\$1,680/);
 assert.match(pages['/kits/pen-case/'],/id="v-price">NT\$1,680/);
 assert.match(pages['/'],/href="\/harui-studio\/kits\/pen-case\/"/);
});
test('FAQ, announcement and news updates appear in their public views',()=>{
 const data=copy();data.site.faq=[{q:'測試提問',a:'店家確認的答案'}];
 data.site.announcement='十月工作室日常';data.site.news=[{title:'測試新消息',date:'2026-10-08',body:'第一行\n第二行'}];
 validate(data,original);const pages=renderSite(data);
 assert.match(pages['/support/'],/測試提問/);assert.match(pages['/support/'],/店家確認的答案/);
 assert.match(pages['/news/'],/測試新消息/);assert.match(pages['/'],/十月工作室日常/);
});
test('reject invalid prices, unsafe links, malformed imports and changed routes',()=>{
 for(const mutate of [d=>d.catalog.kits[0].variants[0].price=-1,d=>d.catalog.kits[0].variants[0].price=NaN,d=>d.catalog.kits[0].variants[0].buyUrl='javascript:alert(1)',d=>d.site.home.heroImage='data:image/svg+xml,<svg/>',d=>d.catalog.kits[0].slug='new-path',d=>delete d.site.contact,d=>d.site.faq.push({q:'',a:''})]){
  const data=copy();mutate(data);assert.throws(()=>validate(data,original));
 }
});
test('content stays escaped inside text, attributes and structured data',()=>{
 const data=copy(),payload=`\"'></script><script>alert(1)</script>`;
 data.site.home.heroTitle=payload;data.catalog.kits[0].variants[0].name=payload;
 const pages=renderSite(data);
 assert.ok(!pages['/'].includes('</script><script>alert(1)'));
 assert.ok(!pages['/kits/pen-case/'].includes("'></script><script>alert(1)"));
 assert.match(pages['/'],/&lt;script&gt;/);
});
test('concurrent saves do not silently overwrite, previous data survives',()=>{
 const storage=memory(),a=copy();const first=save(a,original,null,storage);
 const b=copy();b.site.home.heroTitle='新版標題';save(b,original,first,storage);
 assert.throws(()=>save(a,original,first,storage),/另一個分頁/);
 assert.equal(JSON.parse(storage.getItem(KEY+':previous')).data.site.home.heroTitle,a.site.home.heroTitle);
});
test('a storage quota error leaves the last saved content intact',()=>{
 const storage=memory(),revision=save(copy(),original,null,storage),prior=storage.getItem(KEY);
 const full={getItem:storage.getItem,setItem:()=>{throw new DOMException('Full','QuotaExceededError')}};
 assert.throws(()=>save(copy(),original,revision,full));assert.equal(storage.getItem(KEY),prior);
});
test('all rendered pages and local targets exist at root and GitHub Pages subpath',()=>{
 for(const base of ['', '/harui-studio']){
 const pages=renderSite(copy(),{base});assert.equal(Object.keys(pages).length,12);
 for(const [route,html] of Object.entries(pages)){
  assert.match(html,/<main id="main">/);assert.match(html,/noindex,nofollow/);
  for(const match of html.matchAll(/(?:href|src)="([^"#]+)"/g)){
   let target=match[1].split(/[?#]/)[0];if(!target.startsWith('/'))continue;
   if(base){assert.ok(target.startsWith(base+'/'),`${route}: ${target}`);target=target.slice(base.length)}
   assert.ok(pages[target]||existsSync(new URL('../dist'+target,import.meta.url)),`${route}: missing ${target}`);
  }
 }
 }
});
