import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {renderSite} from '../src/assets/render.mjs';
import {validate,bookingMessage,lineLinks,upcoming,rocDate} from '../src/assets/booking-model.mjs';
const original=JSON.parse(readFileSync(new URL('../content/booking.json',import.meta.url)));
const fixture=()=>structuredClone(original);
const now=Date.parse('2026-10-15T00:00:00+08:00');
const form={items:[{id:original.courses[0].id,quantity:2},{id:original.courses[1].id,quantity:1}],date:'2026-10-22',time:'10:30',name:'測試',age:'25~30',country:'台灣',phone:'0900000000',email:'test@example.com',color:'與店家討論'};
test('catalogue and booking render without cohort registration',()=>{validate(original);for(const base of ['', '/harui-studio-design']){const pages=renderSite(original,{base});assert.ok(pages['/booking/'].includes('挑選作品'));assert.ok(!pages['/booking/'].includes('name="slot"'));assert.ok(pages['/'].includes(base+'/booking/'));}});
test('multiwork totals use current prices and ROC date without automatic discount',()=>{const msg=bookingMessage(original,{...form,offer:'超早鳥'},now);assert.match(msg,/115\/10\/22/);assert.match(msg,/NT\$ 12,100/);assert.match(msg,/× 2 件/);assert.match(msg,/尚未完成訂位/);assert.equal(rocDate('2025-10-10'),'114/10/10');});
test('rejects lead time, closed weekday, unavailable work and invalid quantity',()=>{for(const changes of [{date:'2026-10-16'},{date:'2026-10-25'},{date:'2026-02-30'},{time:'23:00'},{items:[]},{items:[{id:'missing',quantity:1}]},{items:[{id:form.items[0].id,quantity:0}]},{items:[{id:form.items[0].id,quantity:1.5}]},{email:'bad'}])assert.throws(()=>bookingMessage(original,{...form,...changes},now));const d=fixture();d.booking.closedDates=['2026-10-22'];assert.throws(()=>bookingMessage(d,form,now));d.booking.closedDates=[];d.courses[0].status='hidden';assert.throws(()=>bookingMessage(d,form,now));});
test('LINE links preserve encoded summary and official account',()=>{const msg=bookingMessage(original,form,now),links=lineLinks('@nkf1685l',msg);assert.equal(decodeURIComponent(links.message.split('?')[1]),msg);assert.match(links.friend,/%40nkf1685l$/);});
test('invalid settings and unsafe content are rejected or escaped',()=>{for(const change of [d=>d.booking.minDays=0,d=>d.booking.weekdays=[9],d=>d.site.logo='javascript:alert(1)',d=>d.courses[0].price=-1]){const d=fixture();change(d);assert.throws(()=>validate(d));}const d=fixture();d.site.heroTitle='<script>alert(1)</script>';assert.match(renderSite(d)['/'],/&lt;script&gt;/);});
test('catalogue retains every selectable source label and all 17 categories',()=>{const source=JSON.parse(readFileSync(new URL('../content/form-catalog-source.json',import.meta.url)));for(const row of source)for(const label of row.labels)if(label.startsWith('No.')||label.includes('【加購】'))assert.ok(original.courses.some(c=>c.description===label&&c.categories.includes(row.category)),label);assert.equal(new Set(original.courses.flatMap(c=>c.categories)).size,17);});
test('cloud save uses authenticated compare-and-swap and reports conflicts',async()=>{const native=globalThis.fetch;let mode='ok',requests=[];globalThis.fetch=async(url,opts={})=>{requests.push({url,opts});if(String(url).endsWith('/content/cloud.json'))return Response.json({url:'https://example.supabase.co',publishableKey:'public-test',adminEmail:'admin@example.test'});if(String(url).includes('grant_type=password'))return Response.json({access_token:'test-token'});return Response.json(mode==='ok'?[{content:fixture(),revision:4}]:[]);};try{const {login,saveContent}=await import('../src/assets/booking-cloud.mjs');assert.equal((await login('test-password')).access_token,'test-token');const r=await saveContent(fixture(),3,'test-token');assert.equal(r.revision,4);const request=requests.at(-1);assert.match(request.url,/revision=eq.3/);assert.equal(request.opts.headers.Authorization,'Bearer test-token');assert.equal(JSON.parse(request.opts.body).revision,4);mode='conflict';await assert.rejects(()=>saveContent(fixture(),3,'test-token'),/另一個管理者/);}finally{globalThis.fetch=native;}});

test('preview password gate is restricted to unconfigured loopback hosts',async()=>{
 const {localPreviewAllowed,previewPasswordMatches}=await import('../src/assets/admin-access.mjs');
 const empty={url:'',publishableKey:'',adminEmail:''};
 assert.equal(localPreviewAllowed('127.0.0.1',empty),true);
 assert.equal(localPreviewAllowed('localhost',empty),true);
 for(const host of ['ninthlab.com.tw','127.0.0.1.example.com','192.168.1.2'])assert.equal(localPreviewAllowed(host,empty),false);
 for(const key of ['url','publishableKey','adminEmail'])assert.equal(localPreviewAllowed('127.0.0.1',{...empty,[key]:'configured'}),false);
 assert.equal(previewPasswordMatches('123456'),true);
 assert.equal(previewPasswordMatches('wrong'),false);
});

test('per-work colors survive the LINE handoff and stale color IDs are rejected',()=>{
 const colored={...form,items:form.items.map((item,i)=>({...item,colorId:original.leather.colors[i].id}))};
 const msg=bookingMessage(original,colored,now);
 assert.match(msg,/希望皮色：紅色/);assert.match(msg,/希望皮色：黃色/);
 assert.throws(()=>bookingMessage(original,{...form,items:[{...form.items[0],colorId:'removed-color'}]},now),/重新選色/);
 const bad=fixture();bad.leather.colors[0].hex='red; background:url(x)';assert.throws(()=>validate(bad),/色卡/);
});
test('booking retains leather photography and important policies at root and project paths',()=>{
 for(const base of ['', '/harui-studio-design']){
 const html=renderSite(original,{base})['/booking/'];
 for(const image of ['official-leather-works.jpg'])assert.ok(html.includes(base+'/assets/leather/'+image));
 for(const phrase of ['不另行退費','提前三天','請勿攜伴','完成匯款','第拾五號實驗室','85 折','三日內','實際皮革'])assert.ok(html.includes(phrase),phrase);
 for(const color of original.leather.colors)assert.ok(html.includes(color.hex));
 }
});
