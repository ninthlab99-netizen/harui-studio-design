import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {renderSite} from '../src/assets/render.mjs';
import {validate,bookingMessage,lineLinks,upcoming,rocDate} from '../src/assets/booking-model.mjs';
const original=JSON.parse(readFileSync(new URL('../content/booking.json',import.meta.url)));
const fixture=()=>{const d=structuredClone(original);d.site.lineId='@example';d.courses[0].status='open';d.courses[0].slots=[{date:'2026-10-20',time:'10:30',capacity:4,open:true}];return d;};
const now=Date.parse('2026-10-13T00:00:00+08:00');
const form={courseId:'square-tote',slot:'2026-10-20 10:30',people:'2',name:'測試訪客',note:'首次參加'};
test('course content renders without the retired material kit commerce',()=>{const d=fixture();validate(d);d.courses[0].price=9000;for(const base of ['', '/harui-studio-design']){const pages=renderSite(d,{base});assert.match(pages['/'],/NT\$ 9,000/);assert.ok(!pages['/'].includes('材料包'));assert.ok(pages['/'].includes(base+'/booking/'));assert.ok(pages['/booking/'].includes('尚未送出'));assert.ok(!pages['/'].includes('class="seal"'));}});
test('booking summary correctly uses ROC date, time, headcount and current price',()=>{const text=bookingMessage(fixture(),form,now);assert.match(text,/115\/10\/20 大方提袋/);assert.match(text,/人數：2 位/);assert.match(text,/合計 NT\$ 17,000/);assert.match(text,/尚未完成訂位或付款/);assert.equal(rocDate('2025-10-10'),'114/10/10');});
test('LINE message encodes account and Unicode text without sending anything',()=>{const text=bookingMessage(fixture(),form,now),links=lineLinks('@example',text);assert.ok(links.message.startsWith('https://line.me/R/oaMessage/%40example/?'));assert.equal(decodeURIComponent(links.message.split('?')[1]),text);assert.throws(()=>lineLinks('',text));});
test('past, closed, full-size and nonexistent selections cannot create a request',()=>{for(const f of [{...form,people:0},{...form,people:5},{...form,people:1.5},{...form,courseId:'none'},{...form,slot:'2026-10-19 10:30'},{...form,name:''}])assert.throws(()=>bookingMessage(fixture(),f,now));const d=fixture();d.courses[0].slots[0].open=false;assert.throws(()=>bookingMessage(d,form,now));d.courses[0].slots[0].open=true;assert.equal(upcoming(d.courses[0],Date.parse('2026-10-20T02:30:00Z')).length,0);d.courses[0].status='coming';assert.throws(()=>bookingMessage(d,form,now));});
test('invalid dates, price, duplicate slots and unsafe images are rejected',()=>{for(const change of [d=>d.site.logo='javascript:alert(1)',d=>d.site.heroImage='data:image/svg+xml,<svg/>',d=>d.courses[0].price=-1,d=>d.courses[0].slots[0].date='2026-02-30',d=>d.courses[0].slots.push({...d.courses[0].slots[0]}),d=>d.site.lineId='@foo/?bar']){const d=fixture();change(d);assert.throws(()=>validate(d));}});
test('untrusted editable copy is escaped in all public pages',()=>{const d=fixture();d.site.heroTitle='</script><script>alert(1)</script>';d.courses[0].title='" onmouseover="alert(1)';const pages=renderSite(d);assert.match(pages['/'],/&lt;script&gt;/);assert.ok(!pages['/'].includes('</script><script>alert(1)'));assert.ok(!pages['/booking/'].includes('" onmouseover="alert(1)'));});
test('cloud save uses authenticated compare-and-swap and reports conflicts',async()=>{const native=globalThis.fetch;let mode='ok',requests=[];globalThis.fetch=async(url,opts={})=>{requests.push({url,opts});if(String(url).endsWith('/content/cloud.json'))return Response.json({url:'https://example.supabase.co',publishableKey:'public-test',adminEmail:'admin@example.test'});if(String(url).includes('grant_type=password'))return Response.json({access_token:'test-token'});return Response.json(mode==='ok'?[{content:fixture(),revision:4}]:[]);};try{const {login,saveContent}=await import('../src/assets/booking-cloud.mjs');assert.equal((await login('test-password')).access_token,'test-token');const r=await saveContent(fixture(),3,'test-token');assert.equal(r.revision,4);const request=requests.at(-1);assert.match(request.url,/revision=eq.3/);assert.equal(request.opts.headers.Authorization,'Bearer test-token');assert.equal(JSON.parse(request.opts.body).revision,4);mode='conflict';await assert.rejects(()=>saveContent(fixture(),3,'test-token'),/另一個管理者/);}finally{globalThis.fetch=native;}});

test('preview password gate is restricted to unconfigured loopback hosts',async()=>{
 const {localPreviewAllowed,previewPasswordMatches}=await import('../src/assets/admin-access.mjs');
 const empty={url:'',publishableKey:'',adminEmail:''};
 assert.equal(localPreviewAllowed('127.0.0.1',empty),true);
 assert.equal(localPreviewAllowed('localhost',empty),true);
 for(const host of ['ninthlab.com.tw','127.0.0.1.example.com','192.168.1.2'])assert.equal(localPreviewAllowed(host,empty),false);
 for(const key of ['url','publishableKey','adminEmail'])assert.equal(localPreviewAllowed('127.0.0.1',{...empty,[key]:'configured'}),false);
 assert.equal(previewPasswordMatches('123456'),true);
 assert.equal(previewPasswordMatches('wrong'),false);
});
